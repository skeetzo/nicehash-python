# Changelog

**0.0.0 : Testing : 4/22/2021**
	- test_bot.py -> updated original
	**4/25**
	- python unittests: test_nicehash_*public, private, websockets.py
	**0.0.1 : 5/3/2021**
	- package fix